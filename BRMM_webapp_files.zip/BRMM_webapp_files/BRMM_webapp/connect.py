# These details are available on the first MySQL Workbench screen
# Usually called 'Local Instance'
dbuser = "root" # Your MySQL username - likely 'root'
dbpass = "6022681hy" # ---- PUT YOUR PASSWORD HERE ----
dbhost = "localhost" 
dbport = "3306"
dbname = "motorkhana"